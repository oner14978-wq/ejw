trait CameraDrawContext {}
