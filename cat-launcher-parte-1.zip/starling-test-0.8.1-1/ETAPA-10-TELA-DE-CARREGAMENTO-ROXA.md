# ETAPA 10 - tela de carregamento roxa ligada ao progresso real - NÃO COMPILADO, NÃO TESTADO NO APARELHO

Sem cargo, NDK, Android SDK, rede ou aparelho neste ambiente. Validado só: sintaxe do JS e do SVG de loading.html, py_compile do build_apk.py.

## Fluxo
JOGAR (CatHomeActivity.launch, já direto, sem tela intermediária) -> StarlingActivity (processo do jogo) cria CatLoadingOverlay por cima da janela
-> Rust (cat_progress.rs) grava files/cat-progress.json a cada etapa real -> o overlay lê a cada 150 ms e move a barra -> ao entregar a janela ao jogo
(loading_screen.rs, Step::Ready) grava "ready" = 100% -> overlay some. Sem segunda espera.

## Etapas e faixas da barra (só avançam quando a etapa informa)
- Arquivos da versão (bytes reais baixados/total): 0-35   | Java (bytes): 35-45 | Descompactar Java: 45-50
- Preparo dos recursos (horizon-prepare não informa contagem: a barra fica no início da faixa, sem animação inventada): 50-80
- Carregamento do jogo (checkpoints reais do loader, STAGE_LINES): 80-98 | entrega da janela ao jogo: 100
- Início com arquivos já preparados: o loader ocupa 0-98 (não salta).
- Pede login/pergunta: overlay se esconde (tela do jogo). Falha: overlay some e aparece a tela de erro/Tentar de novo do jogo.

## Arquivos
NOVO crates/horizon-client/src/cat_progress.rs (+ lib.rs) | starling/setup/mod.rs: report_cat_progress | runtime/loading_screen.rs: chamada em draw() e ready no handoff
NOVO packaging/android/cat/loading.html (tela roxa) | NOVO CatLoadingOverlay.java | StarlingActivity.java | build_apk.py (empacota loading.html)

## Riscos a checar no primeiro build
1. private_home() (Rust) tem de ser o mesmo getFilesDir() (Java): se HORIZON_PRIVATE não apontar para lá, o overlay não recebe nada.
2. "ready" = jogo recebeu a janela (handoff). Conferir se o menu já aparece nesse instante.
3. addContentView sobre a NativeActivity e WebView com file:///android_asset.
4. Sem como medir o Preparing: em primeira instalação a barra para em 50% durante o preparo (detalhe mostra o passo real).
