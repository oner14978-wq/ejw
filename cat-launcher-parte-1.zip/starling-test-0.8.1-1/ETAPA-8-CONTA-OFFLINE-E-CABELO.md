# ETAPA 8 — Conta Offline real + cabelo do Steve

## Executado de verdade
- tests/cat/offline_test.py (Chromium real, motor SIMULADO em JS): 68/68 — tela Conta Offline, validação, criar/reabrir, JOGAR com/sem conta, cabelo em camisas/calças/sapatos/chapéus/acessórios/capas/Alex, skin importada 64x64 e 64x32, salvar/reabrir.
- OfflineProfile.java compilado com jdk.compiler e executado: UUID de "Steve" = 5627dd98-e6be-3c21-b8a8-e92344183641 (igual ao Java do Minecraft); validação 3–16 [A-Za-z0-9_].

## Editado, NÃO compilado (sem cargo/NDK/SDK aqui)
- cat_bridge.rs: removidos sign_in_microsoft/sign_in_ely/cancel_sign_in/sign_out/open_link; add_offline devolve name+uuid e grava cat-offline-profile.json; state traz uuids; testes unitários novos.
- setup/mod.rs: o Play do Cat Launcher força o perfil offline mesmo com conta Microsoft salva.
- CatHomeActivity.java: launch só offline, confere o UUID. Não compilado (precisa do android.jar).

## Não feito
- Botões Microsoft/Ely da tela de preparo do próprio jogo (setup/mod.rs Step::Start) e o código starling-account continuam no motor.
- Minecraft abrir no aparelho: não testado.
- Steve é textura procedural (a original da Mojang não está no projeto); fonte pixel gerada, não a do Minecraft.
